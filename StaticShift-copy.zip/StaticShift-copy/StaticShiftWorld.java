
import greenfoot.*;

public class StaticShiftWorld extends World {

    private int score = 0;
    private int lives = 3;
    private boolean gameOver = false;

    public StaticShiftWorld() {
        super(900, 550, 1);

        prepare();
        updateDisplay();
    }

    private void prepare() {

        // Add robot
        addObject(new Robot(), 100, 430);

        // Add five batteries
        addObject(new Battery(), 230, 430);
        addObject(new Battery(), 350, 430);
        addObject(new Battery(), 470, 430);
        addObject(new Battery(), 590, 430);
        addObject(new Battery(), 770, 430);

        // security drone
        addObject(new SecurityDrone(), 690, 350);
    }

    // Increase score when collecting battery
    public void addScore() {

        if (gameOver) {
            return;
        }

        score++;
        updateDisplay();

        // Win after collecting all five batterie
        if (score >= 5) {
            gameOver = true;
            showText("YOU WIN!", 450, 250);
            Greenfoot.stop();
        }
    }

    // Remove a life when touching the drone
    public void loseLife() {

        if (gameOver) {
            return;
        }

        lives--;
        updateDisplay();

        // Game over when no lives remain
        if (lives <= 0) {
            gameOver = true;
            showText("GAME OVER", 450, 250);
            Greenfoot.stop();
        }
    }

    // Check whether the game has ended
    public boolean isGameOver() {
        return gameOver;
    }

    // Update score and lives displayed on screen
    private void updateDisplay() {

        showText("SCORE: " + score + " / 5", 100, 30);
        showText("LIVES: " + lives, 800, 30);
    }
}
