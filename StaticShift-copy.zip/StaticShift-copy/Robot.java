



import greenfoot.*;

public class Robot extends Actor {

    private int verticalSpeed = 0;
    private final int groundY = 430;

    // Prevent repeated drone collisions
    private int collisionCooldown = 0;

    public void act() {

        StaticShiftWorld world = (StaticShiftWorld) getWorld();

        if (world.isGameOver()) {
            return;
        }

        // Reduce collision cooldown
        if (collisionCooldown > 0) {
            collisionCooldown--;
        }

        movePlayer();
        checkCollisions();
    }

    // Player movement and jumping
    private void movePlayer() {

        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 4, getY());
        }

        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 4, getY());
        }

        if (Greenfoot.isKeyDown("up") && getY() >= groundY) {
            verticalSpeed = -14;
        }

        // Gravity
        verticalSpeed++;

        int newY = getY() + verticalSpeed;

        if (newY >= groundY) {
            newY = groundY;
            verticalSpeed = 0;
        }

        setLocation(getX(), newY);
    }

    // Battery collection and drone collisions
    private void checkCollisions() {

        StaticShiftWorld world = (StaticShiftWorld) getWorld();

        // Check battery collection
        Battery battery =
            (Battery) getOneIntersectingObject(Battery.class);

        if (battery != null) {

            world.removeObject(battery);

            // Play collection sound
            Greenfoot.playSound("battery.wav");

            world.addScore();

            if (world.isGameOver()) {
                return;
            }
        }

        // Check security drone collision
        SecurityDrone drone =
            (SecurityDrone) getOneIntersectingObject(
                SecurityDrone.class
            );

        if (drone != null && collisionCooldown == 0) {

            // Play damage sound
            Greenfoot.playSound("damage.wav");

            world.loseLife();

            // Respawn if the game isn't over
            if (!world.isGameOver()) {

                setLocation(100, groundY);
                verticalSpeed = 0;

                // Temporary collision protection
                collisionCooldown = 60;
            }
        }
    }
}
